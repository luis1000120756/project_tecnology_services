<?php

namespace Illuminate\Support;

use RuntimeException;

class ItemNotFoundException extends RuntimeException
{
}
